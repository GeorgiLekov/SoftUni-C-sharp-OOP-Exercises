﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T03.Telephony
{
    public interface ICallNumbers
    {
        public void CallNumber(string number);
    }
}
