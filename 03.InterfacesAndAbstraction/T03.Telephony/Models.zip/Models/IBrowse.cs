﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T03.Telephony
{
    public interface IBrowse
    {
        public void BrowseWebsites(string url);
    }
}
