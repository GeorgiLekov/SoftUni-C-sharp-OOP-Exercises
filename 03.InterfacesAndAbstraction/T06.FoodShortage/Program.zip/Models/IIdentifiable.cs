﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T06.FoodShortage
{
    public interface IIdentifiable
    {
        public string ID { get; set; }
    }
}
