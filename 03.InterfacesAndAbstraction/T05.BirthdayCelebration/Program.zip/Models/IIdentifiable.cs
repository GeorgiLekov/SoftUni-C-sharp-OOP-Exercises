﻿using System;
using System.Collections.Generic;
using System.Text;

namespace T05.BirthdayCelebration
{
    public interface IIdentifiable
    {
        public string ID { get; set; }
    }
}
