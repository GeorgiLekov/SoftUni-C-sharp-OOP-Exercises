﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.PlayersAndMonsters
{
    public class DarkKnight : Knight
    {
        public DarkKnight(string name, int age) : base(name, age)
        {

        }
    }
}
