﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.PlayersAndMonsters
{
    public class Knight : Hero
    {
        public Knight(string name, int age) : base(name, age)
        {

        }
    }
}
